﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Collections.Generic;
using System.Collections.Immutable;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace ZilfAnalyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    [SuppressMessage("MicrosoftCodeAnalysisCorrectness", "RS1038:Compiler extensions should be implemented in assemblies with compiler-provided references", Justification = "<Pending>")]
    [SuppressMessage("MicrosoftCodeAnalysisCorrectness", "RS1041:Compiler extensions should be implemented in assemblies targeting netstandard2.0", Justification = "<Pending>")]
    public class ZilObjectAnalyzer : DiagnosticAnalyzer
    {
        static readonly DiagnosticDescriptor Rule_ComparingZilObjectsWithEquals = new(
            DiagnosticIds.ComparingZilObjectsWithEquals,
            "Comparing ZilObjects with Equals",
            "'{0}' is for hash-safe comparisons: prefer methods with explicit MDL comparison behavior",
            "Values",
            DiagnosticSeverity.Warning,
            isEnabledByDefault: true);

        static readonly DiagnosticDescriptor Rule_PartiallyOverriddenZilObjectComparison = new(
            DiagnosticIds.PartiallyOverriddenZilObjectComparison,
            "Partially overridden ZilObject comparison",
            "'{0}' overrides {1} but does not override {2}",
            "Values",
            DiagnosticSeverity.Warning,
            isEnabledByDefault: true);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get; } =
            [Rule_ComparingZilObjectsWithEquals, Rule_PartiallyOverriddenZilObjectComparison];

        public override void Initialize([NotNull] AnalysisContext context)
        {
            context.EnableConcurrentExecution();
            context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.Analyze | GeneratedCodeAnalysisFlags.ReportDiagnostics);
            context.RegisterSyntaxNodeAction(AnalyzeMemberAccessishNode, SyntaxKind.SimpleMemberAccessExpression, SyntaxKind.ConditionalAccessExpression);
            context.RegisterSyntaxNodeAction(AnalyzeInvocationNode, SyntaxKind.InvocationExpression);
            context.RegisterSymbolAction(AnalyzeClassSymbol, SymbolKind.NamedType);
        }

        static readonly ImmutableArray<(string ifThis, string thenThat)> MethodsToOverrideTogether =
            [("Equals", "ExactlyEquals"), ("ExactlyEquals", "GetHashCode")];

        static void AnalyzeClassSymbol(SymbolAnalysisContext context)
        {
            var type = (INamedTypeSymbol)context.Symbol;

            var zilObjectType = context.Compilation
                .GetTypeByMetadataName("Zilf.Interpreter.Values.ZilObject");

            if (zilObjectType == null)
                return;

            if (!GetTypeAndBases(type).Contains(zilObjectType, SymbolEqualityComparer.Default))
                return;

            foreach (var (ifThis, thenThat) in MethodsToOverrideTogether)
            {
                if (TypeOverridesBaseMethod(type, ifThis, zilObjectType, out var overridingMethod, out var baseEqualsMethod) &&
                    !TypeOverridesBaseMethod(type, thenThat, zilObjectType, out _, out var baseExactlyEqualsMethod))
                {
                    var diagnostic = Diagnostic.Create(
                        Rule_PartiallyOverriddenZilObjectComparison,
                        overridingMethod.Locations[0],
                        type.ToDisplayString(SymbolDisplayFormat.CSharpShortErrorMessageFormat),
                        baseEqualsMethod.ToDisplayString(SymbolDisplayFormat.CSharpShortErrorMessageFormat),
                        baseExactlyEqualsMethod?.ToDisplayString(SymbolDisplayFormat.CSharpShortErrorMessageFormat));

                    context.ReportDiagnostic(diagnostic);
                }
            }
        }

        static bool TypeOverridesBaseMethod(ITypeSymbol derivedType, string methodName,
            [NotNull] ITypeSymbol baseType,
            [NotNullWhen(true)] out IMethodSymbol? overridingMethod,
            [NotNullWhen(true)] out IMethodSymbol? overriddenMethod)
        {
            var derivedMethods = derivedType.GetMembers(methodName).OfType<IMethodSymbol>().Where(m => !m.IsStatic);

            foreach (var dm in derivedMethods)
            {
                foreach (var bm in GetMethodAndOverridden(dm))
                {
                    if (GetTypeAndBases(baseType).Contains(bm.ContainingType, SymbolEqualityComparer.Default))
                    {
                        overridingMethod = dm;
                        overriddenMethod = bm;
                        return true;
                    }
                }
            }

            overridingMethod = null;
            overriddenMethod = GetTypeAndBases(baseType)
                .SelectMany(t => t.GetMembers(methodName))
                .OfType<IMethodSymbol>()
                .FirstOrDefault(m => !m.IsStatic);
            return false;
        }

        static void AnalyzeInvocationNode(SyntaxNodeAnalysisContext context)
        {
            var invocation = (InvocationExpressionSyntax)context.Node;

            if (invocation.ArgumentList.Arguments.Count == 0)
                return;

            if (!DetectMemberAccess(invocation.Expression, out var objType, out var memberNode, context.SemanticModel))
                return;

            var memberSymInfo = context.SemanticModel.GetSymbolInfo(memberNode);

            if (memberSymInfo.Symbol is IMethodSymbol resolvedMethod)
            {
                CheckCallToMethod(resolvedMethod);
            }
            else if (!memberSymInfo.CandidateSymbols.IsEmpty)
            {
                foreach (var candidateMethod in memberSymInfo.CandidateSymbols.OfType<IMethodSymbol>())
                    if (CheckCallToMethod(candidateMethod))
                        break;
            }

            bool CheckCallToMethod(IMethodSymbol method)
            {
                var zilObjectType = context.Compilation?.GetTypeByMetadataName("Zilf.Interpreter.Values.ZilObject");

                if (zilObjectType == null)
                    return false;

                var argTypes = from a in invocation.ArgumentList.Arguments.Take(2)
                               select context.SemanticModel.GetTypeInfo(a.Expression).Type;

                if (method.MethodKind == MethodKind.ReducedExtension)
                {
                    // convert foo.SequenceEqual(bar) to Enumerable.SequenceEqual(foo, bar)
                    Debug.Assert(method.ReducedFrom != null);
                    method = method.ReducedFrom;
                    argTypes = new[] { objType }.Concat(argTypes);
                }

                if (IsEqualsBasedAssertion(method))
                {
                    // applies if any argument inherits from ZilObject
                    if (!argTypes.Any(argType => GetTypeAndBases(argType).Contains(zilObjectType, SymbolEqualityComparer.Default)))
                        return false;
                }
                else if (IsEqualsBasedCollectionComparison(method))
                {
                    // applies if any argument implements IEnumerable<ZilObject>
                    var enumerableType =
                        context.Compilation?.GetSpecialType(SpecialType.System_Collections_Generic_IEnumerable_T);
                    var zilObjectEnumerableType = enumerableType?.Construct(zilObjectType);

                    if (zilObjectEnumerableType == null)
                        return false;

                    if (!argTypes.Any(argType =>
                        context.Compilation.ClassifyConversion(argType, zilObjectEnumerableType).IsImplicit))
                        return false;
                }
                else
                {
                    // doesn't apply
                    return false;
                }

                var diagnostic = Diagnostic.Create(
                    Rule_ComparingZilObjectsWithEquals,
                    context.Node.GetLocation(),
                    method.ToDisplayString(SymbolDisplayFormat.CSharpShortErrorMessageFormat));

                context.ReportDiagnostic(diagnostic);
                return true;
            }
        }

        static bool IsEqualsBasedCollectionComparison([NotNull] IMethodSymbol method)
        {
            // collection comparisons:
            //   Microsoft.VisualStudio.TestTools.UnitTesting.CollectionAssert (AreEqual, AreEquivalent, Contains, and negations)
            //   System.Linq.Enumerable (SequenceEqual`1)

            var containingType = method.ContainingType;

            switch (containingType.Name)
            {
                case "CollectionAssert" when containingType.ContainingNamespace.ToString() == "Microsoft.VisualStudio.TestTools.UnitTesting":
                    switch (method.Name)
                    {
                        case "AreEqual":
                        case "AreEquivalent":
                        case "Contains":
                        case "AreNotEqual":
                        case "AreNotEquivalent":
                        case "DoesNotContain":
                            return true;
                    }
                    break;

                case "Enumerable" when containingType.ContainingNamespace.ToString() == "System.Linq":
                    switch (method.Name)
                    {
                        case "SequenceEqual":
                            return true;
                    }
                    break;
            }

            return false;
        }

        static bool IsEqualsBasedAssertion([NotNull] IMethodSymbol method)
        {
            var containingType = method.ContainingType;

            if (containingType.Name == "Assert" &&
                containingType.ContainingNamespace.ToString() == "Microsoft.VisualStudio.TestTools.UnitTesting")
            {
                switch (method.Name)
                {
                    case "AreEqual":
                    case "AreNotEqual":
                        return true;
                }
            }
            else if (containingType.SpecialType == SpecialType.System_Object)
            {
                if (method.Name == "Equals" && method.IsStatic)
                    return true;
            }

            return false;
        }

        static void AnalyzeMemberAccessishNode(SyntaxNodeAnalysisContext context)
        {
            var zilObjectType = context.Compilation?.GetTypeByMetadataName("Zilf.Interpreter.Values.ZilObject");

            if (zilObjectType == null)
                return;

            if (!DetectMemberAccess(context.Node, out var objType, out var memberNode, context.SemanticModel))
                return;

            if (objType == null || !GetTypeAndBases(objType).Contains(zilObjectType, SymbolEqualityComparer.Default))
                return;

            var zilObjectEquals = GetTypeAndBases(zilObjectType)
                .SelectMany(t => t.GetMembers("Equals"))
                .First(s => !s.IsStatic);

            var memberSymInfo = context.SemanticModel.GetSymbolInfo(memberNode);

            if (memberSymInfo.Symbol is IMethodSymbol method &&
                GetMethodAndOverridden(method).Contains(zilObjectEquals, SymbolEqualityComparer.Default))
            {
                var diagnostic = Diagnostic.Create(
                    Rule_ComparingZilObjectsWithEquals,
                    context.Node.GetLocation(),
                    method.ToDisplayString(SymbolDisplayFormat.CSharpShortErrorMessageFormat));

                context.ReportDiagnostic(diagnostic);
            }
        }

        static bool DetectMemberAccess([NotNull] SyntaxNode node, out ITypeSymbol? objectType, [NotNullWhen(true)] out ExpressionSyntax? memberNode, SemanticModel model)
        {
            switch (node)
            {
                case MemberAccessExpressionSyntax mem:
                    memberNode = mem;
                    objectType = model.GetTypeInfo(mem.Expression).Type;
                    return true;

                case ConditionalAccessExpressionSyntax cond:
                    if (cond.WhenNotNull is InvocationExpressionSyntax invocation &&
                        invocation.Expression is MemberBindingExpressionSyntax memb)
                    {
                        memberNode = memb;
                        objectType = model.GetTypeInfo(cond.Expression).Type;
                        return true;
                    }
                    break;

                case IdentifierNameSyntax ident:
                    var sym = model.GetSymbolInfo(ident).Symbol;
                    if (sym is IMethodSymbol method)
                    {
                        objectType = method.ContainingType;
                        memberNode = ident;
                        return true;
                    }
                    break;
            }

            memberNode = null;
            objectType = null;
            return false;
        }

        static IEnumerable<ITypeSymbol> GetTypeAndBases([DisallowNull] ITypeSymbol? type)
        {
            while (type != null)
            {
                yield return type;

                type = type.BaseType;
            }
        }

        static IEnumerable<IMethodSymbol> GetMethodAndOverridden([DisallowNull] IMethodSymbol? method)
        {
            while (method != null)
            {
                yield return method;

                method = method.OverriddenMethod;
            }
        }
    }
}