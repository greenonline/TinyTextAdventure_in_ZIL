﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Zilf.Interpreter.Values;

namespace Zilf.ZModel
{
    sealed class AtomNameEqualityComparer : IEqualityComparer<ZilAtom>
    {
        readonly bool ignoreCase;

        public AtomNameEqualityComparer(bool ignoreCase)
        {
            this.ignoreCase = ignoreCase;
        }

        public bool Equals([AllowNull] ZilAtom x, [AllowNull] ZilAtom y)
        {
            if (x == y)
                return true;

            if (x == null || y == null)
                return false;

            return x.Text.Equals(y.Text, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
        }

        public int GetHashCode(ZilAtom? obj)
        {
            if (obj == null)
                return 0;

            return obj.Text.GetHashCode(ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
        }
    }
}
