﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using Zilf.Language;
using Zilf.Diagnostics;
using System.Collections.Generic;
using System;

namespace Zilf.Interpreter.Values
{
    [BuiltinType(StdAtom.SUBR, PrimType.STRING)]
    class ZilSubr : ZilObject, IApplicable
    {
        protected readonly string name;

        protected readonly SubrDelegate handler;

        public ZilSubr(string name, SubrDelegate handler)
        {
            this.name = name;
            this.handler = handler;
        }

        [ChtypeMethod]
        public static ZilSubr FromString(Context ctx, ZilString str) =>
            FromString(ctx, str.ToStringContext(ctx, true));

        public static ZilSubr FromString(Context ctx, string name)
        {
            var del = ctx.GetSubrDelegate(name);
            if (del != null)
            {
                return new ZilSubr(name, del);
            }
            throw new InterpreterError(InterpreterMessages.Unrecognized_SUBR_FSUBR_Name_0, name);
        }

        public override string ToString() => $"#SUBR \"{name}\"";

        public override StdAtom StdTypeAtom => StdAtom.SUBR;

        public override PrimType PrimType => PrimType.STRING;

        public override ZilObject GetPrimitive(Context ctx) => ZilString.FromString(name);

        public virtual ZilResult Apply(Context ctx, ZilObject[] args)
        {
            var argList = new List<ZilObject>(args.Length);
            foreach (var r in EvalSequence(ctx, args))
            {
                if (r.ShouldPass())
                    return r;

                argList.Add((ZilObject)r);
            }

            return handler(name, ctx, argList.ToArray());
        }

        public ZilResult ApplyNoEval(Context ctx, ZilObject[] args) => handler(name, ctx, args);

        public override bool ExactlyEquals(ZilObject? obj)
        {
            return
                obj is ZilSubr other &&
                other.GetType() == GetType() &&
                other.name.Equals(name, StringComparison.Ordinal) &&
                other.handler.Equals(handler);
        }

        public override int GetHashCode() => handler.GetHashCode();
    }
}