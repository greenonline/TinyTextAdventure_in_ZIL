﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Diagnostics;
using System.Linq;
using Zilf.Interpreter.Values;
using Zilf.Language;
using Zilf.Diagnostics;

namespace Zilf.Interpreter
{
    static partial class Subrs
    {
        /// <summary>
        /// Begins a new package with the specified name.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="pname">The name of the package.</param>
        /// <returns>The package's external atom, i.e. the atom whose OBLIST property is the oblist containing atoms
        /// exported from the package (such as PNAME!-PACKAGE).</returns>
        [Subr]
        [Subr("ZPACKAGE")]
        [Subr("ZZPACKAGE")]
        public static ZilObject PACKAGE(Context ctx, string pname)
        {
            // external oblist
            var externalAtom = ctx.PackageObList[pname];
            var externalObList = ctx.GetProp(externalAtom, ctx.GetStdAtom(StdAtom.OBLIST)) as ObList ?? ctx.MakeObList(externalAtom);

            // internal oblist
            var iname = "I" + pname;
            var internalAtom = externalObList[iname];
            var internalObList = ctx.GetProp(internalAtom, ctx.GetStdAtom(StdAtom.OBLIST)) as ObList ?? ctx.MakeObList(internalAtom);

            // new oblist path
            var newObPath = new ZilList(new ZilObject[] { internalObList, externalObList, ctx.RootObList });
            ctx.PushObPath(newObPath);
            ctx.SetGlobalVal(externalAtom, newObPath);

            // package type
            ctx.PutProp(externalObList, ctx.GetStdAtom(StdAtom.PACKAGE), ctx.GetStdAtom(StdAtom.PACKAGE));

            return externalAtom;
        }

        /// <summary>
        /// Begins a new definition package with the specified name.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="pname">The name of the package.</param>
        /// <returns>The package's external atom, i.e. the atom whose OBLIST property is the oblist containing atoms
        /// exported from the package (such as PNAME!-PACKAGE).</returns>
        [Subr]
        [Subr("ZSECTION")]
        [Subr("ZZSECTION")]
        public static ZilObject DEFINITIONS(Context ctx, string pname)
        {
            // external oblist
            var externalAtom = ctx.PackageObList[pname];
            var externalObList = ctx.GetProp(externalAtom, ctx.GetStdAtom(StdAtom.OBLIST)) as ObList ?? ctx.MakeObList(externalAtom);

            // new oblist path
            var newObPath = new ZilList(new ZilObject[] { externalObList, ctx.RootObList });
            ctx.PushObPath(newObPath);
            ctx.SetGlobalVal(externalAtom, newObPath);

            // package type
            ctx.PutProp(externalObList, ctx.GetStdAtom(StdAtom.PACKAGE), ctx.GetStdAtom(StdAtom.DEFINITIONS));

            return externalAtom;
        }

        /// <summary>
        /// Ends the current package or definition package.
        /// </summary>
        /// <param name="ctx"></param>
        /// <returns>The oblist path that was in effect before ending the package.</returns>
        [Subr]
        [Subr("END-DEFINITIONS")]
        [Subr("ENDSECTION")]
        public static ZilObject ENDPACKAGE(Context ctx)
        {
            return ENDBLOCK(ctx);
        }

        /// <summary>
        /// Exports the specified atoms from the current package by placing them on the package's external oblist.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="args">The atoms to export.</param>
        /// <returns>True.</returns>
        /// <exception cref="InterpreterError">OBLIST path is malformed.</exception>
        [Subr]
        public static ZilObject ENTRY(Context ctx, ZilAtom[] args)
        {
            if (ctx.GetLocalVal(ctx.GetStdAtom(StdAtom.OBLIST)) is not ZilList currentObPath ||
                currentObPath.GetLength(1) != null ||
                currentObPath.Take(2).Any(zo => zo.StdTypeAtom != StdAtom.OBLIST))
            {
                throw new InterpreterError(
                    InterpreterMessages._0_Value_Of_1_Must_Be_2,
                    "local",
                    "OBLIST",
                    "a list starting with 2 OBLISTs");
            }

            Debug.Assert(currentObPath.First != null);
            Debug.Assert(currentObPath.Rest != null);
            Debug.Assert(currentObPath.Rest.First is ObList);

            var internalObList = (ObList)currentObPath.First;
            var externalObList = (ObList)currentObPath.Rest.First;

            // make sure we're inside a PACKAGE
            var packageAtom = ctx.GetStdAtom(StdAtom.PACKAGE);
            if (ctx.GetProp(internalObList, packageAtom) != null || ctx.GetProp(externalObList, packageAtom) != packageAtom)
                throw new InterpreterError(InterpreterMessages._0_Must_Be_Called_From_Within_A_PACKAGE, "ENTRY");

            var onWrongOblist = args.Where(a => a.ObList != internalObList && a.ObList != externalObList).ToList();
            if (onWrongOblist.Count > 0)
            {
                throw new InterpreterError(
                    InterpreterMessages._0_All_Atoms_Must_Be_On_Internal_Oblist_1_Failed_For_2,
                    "ENTRY",
                    ctx.GetProp(internalObList, ctx.GetStdAtom(StdAtom.OBLIST))?.ToStringContext(ctx, false) ?? "<null>",
                    string.Join(", ", onWrongOblist.Select(a => a.ToStringContext(ctx, false))));
            }

            foreach (var atom in args)
                atom.ObList = externalObList;

            return ctx.TRUE;
        }

        /// <summary>
        /// Exports the specified atoms from the current package by placing them on the root oblist.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="args">The atoms to export.</param>
        /// <returns>True.</returns>
        /// <exception cref="InterpreterError">OBLIST path is malformed.</exception>
        [Subr]
        public static ZilObject RENTRY(Context ctx, ZilAtom[] args)
        {
            if (ctx.GetLocalVal(ctx.GetStdAtom(StdAtom.OBLIST)) is not ZilList currentObPath ||
                currentObPath.GetLength(1) != null ||
                currentObPath.Take(2).Any(zo => zo.StdTypeAtom != StdAtom.OBLIST))
            {
                throw new InterpreterError(
                    InterpreterMessages._0_Value_Of_1_Must_Be_2,
                    "local",
                    "OBLIST",
                    "a list starting with 2 OBLISTs");
            }

            Debug.Assert(currentObPath.First != null);
            Debug.Assert(currentObPath.Rest != null);
            Debug.Assert(currentObPath.Rest.First is ObList);

            var internalObList = (ObList)currentObPath.First;
            var externalObList = (ObList)currentObPath.Rest.First;

            // make sure we're inside a PACKAGE or DEFINITIONS
            var packageAtom = ctx.GetStdAtom(StdAtom.PACKAGE);
            var internalPackageProp = ctx.GetProp(internalObList, packageAtom);
            var externalPackageProp = ctx.GetProp(externalObList, packageAtom);
            if (internalPackageProp != ctx.GetStdAtom(StdAtom.DEFINITIONS) && externalPackageProp != packageAtom)
                throw new InterpreterError(InterpreterMessages._0_Must_Be_Called_From_Within_A_PACKAGE_Or_DEFINITIONS, "RENTRY");

            var onWrongOblist = args.Where(a => a.ObList != internalObList && a.ObList != ctx.RootObList).ToList();
            if (onWrongOblist.Count > 0)
            {
                throw new InterpreterError(InterpreterMessages._0_All_Atoms_Must_Be_On_Internal_Oblist_1_Failed_For_2,
                    "RENTRY",
                    ctx.GetProp(internalObList, ctx.GetStdAtom(StdAtom.OBLIST))?.ToStringContext(ctx, false) ?? "<null>",
                    string.Join(", ", onWrongOblist.Select(a => a.ToStringContext(ctx, false))));
            }

            foreach (var atom in args)
                atom.ObList = ctx.RootObList;

            return ctx.TRUE;
        }

        /// <summary>
        /// Imports the specified packages into the current OBLIST path, possibly loading them from files.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="args">The packages to import.</param>
        /// <returns>True.</returns>
        [Subr]
        public static ZilObject USE(Context ctx, string[] args)
        {
            return PerformUse(ctx, args, "USE", StdAtom.PACKAGE);
        }

        /// <summary>
        /// Imports the specified definition packages into the current OBLIST path, possibly loading them from files.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="args">The definition packages to import.</param>
        /// <returns>True.</returns>
        [Subr]
        public static ZilObject INCLUDE(Context ctx, string[] args)
        {
            return PerformUse(ctx, args, "INCLUDE", StdAtom.DEFINITIONS);
        }

        /// <summary>
        /// Imports the specified packages into the current OBLIST path if the condition is true, possibly loading them from files.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="condition">The condition to evaluate.</param>
        /// <param name="args">The packages to import.</param>
        /// <returns>True if the condition is true and the packages were imported; otherwise, the condition.</returns>
        [Subr("USE-WHEN")]
        public static ZilObject USE_WHEN(Context ctx, ZilObject condition, string[] args)
        {
            return condition.IsTrue ? PerformUse(ctx, args, "USE-WHEN", StdAtom.PACKAGE) : condition;
        }

        /// <summary>
        /// Imports the specified definition packages into the current OBLIST path if the condition is true, possibly loading them from files.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="condition">The condition to evaluate.</param>
        /// <param name="args">The definition packages to import.</param>
        /// <returns>True if the condition is true and the definition packages were imported; otherwise, the condition.</returns>
        [Subr("INCLUDE-WHEN")]
        public static ZilObject INCLUDE_WHEN(Context ctx, ZilObject condition, string[] args)
        {
            return condition.IsTrue ? PerformUse(ctx, args, "INCLUDE-WHEN", StdAtom.DEFINITIONS) : condition;
        }

        static ZilObject PerformUse(Context ctx, string[] args, string name, StdAtom requiredPackageType)
        {
            if (ctx.GetLocalVal(ctx.GetStdAtom(StdAtom.OBLIST)) is not ZilList obpath)
            {
                throw new InterpreterError(
                    InterpreterMessages._0_Value_Of_1_Must_Be_2,
                    "local",
                    "OBLIST",
                    "a list starting with 2 OBLISTs");
            }

            if (args.Length == 0)
                return ctx.TRUE;

            var obpathList = obpath.ToList();

            foreach (var packageName in args)
            {
                if (!ctx.PackageObList.Contains(packageName))
                {
                    // try loading from file
                    PerformLoadFile(ctx, packageName, name);  // throws on failure
                }

                ObList? externalObList = null;
                if (ctx.PackageObList.Contains(packageName))
                {
                    var packageNameAtom = ctx.PackageObList[packageName];
                    externalObList = ctx.GetProp(packageNameAtom, ctx.GetStdAtom(StdAtom.OBLIST)) as ObList;
                }

                if (externalObList == null)
                    throw new InterpreterError(InterpreterMessages._0_Unrecognized_Package_1, name, packageName);

                if (ctx.GetProp(externalObList, ctx.GetStdAtom(StdAtom.PACKAGE)) is not ZilAtom pkgTypeAtom ||
                    pkgTypeAtom.StdAtom != requiredPackageType)
                {
                    throw new InterpreterError(InterpreterMessages._0_Wrong_Package_Type_Expected_1, name, ctx.GetStdAtom(requiredPackageType).ToString());
                }

                if (!obpathList.Contains(externalObList))
                    obpathList.Add(externalObList);
            }

            ctx.SetLocalVal(ctx.GetStdAtom(StdAtom.OBLIST), new ZilList(obpathList));
            return ctx.TRUE;
        }

        /// <summary>
        /// Returns true.
        /// </summary>
        /// <param name="ctx"></param>
        /// <param name="args">Ignored.</param>
        /// <returns>True.</returns>
        [Subr("COMPILING?")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0060:Remove unused parameter", Justification = "Arguments are discarded.")]
        public static ZilObject COMPILING_P(Context ctx, ZilObject[] args)
        {
            // always true
            return ctx.TRUE;
        }
    }
}