﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Zilf.Diagnostics;
using Zilf.Emit;
using Zilf.Interpreter;
using Zilf.Interpreter.Values;
using Zilf.Language;
using Zilf.ZModel;
using Zilf.ZModel.Values;
using Zilf.ZModel.Vocab;

namespace Zilf.Compiler
{
    partial class Compilation
    {
        [return: NotNullIfNotNull(nameof(flag))]
        IFlagBuilder? GetFlag(ZilAtom? flag)
        {
            if (flag == null)
                return null;

            if (Context.ZEnvironment.TryGetBitSynonym(flag, out var originalFlag))
            {
                flag = originalFlag;
            }

            DefineFlag(flag);
            return Flags[flag];
        }

        void DefineProperty(ZilAtom prop)
        {
            if (!Properties.ContainsKey(prop))
            {
                // create property builder
                var pb = Game.DefineProperty(prop.Text);
                Properties.Add(prop, pb);

                // create constant
                string propConstName = "P?" + prop.Text;
                var propAtom = ZilAtom.Parse(propConstName, Context);
                Constants.Add(propAtom, pb);
            }
        }

        void DefineFlag(ZilAtom flag)
        {
            if (!Flags.ContainsKey(flag))
            {
                // create flag builder
                var fb = Game.DefineFlag(flag.Text);
                Flags.Add(flag, fb);
                UniqueFlags++;

                // create constant
                Constants.Add(flag, fb);
            }
        }

        void DefineFlagAlias(ZilAtom alias, ZilAtom original)
        {
            if (!Flags.ContainsKey(alias))
            {
                var fb = Flags[original];
                Constants.Add(alias, fb);
            }
        }

        /// <summary>
        /// Contains unique atoms used as special values in <see cref="PreBuildObject( ZilModelObject)"/>.
        /// </summary>
        /// <remarks>
        /// Since DESC and IN (or LOC) can be used as property names when the property definition
        /// matches the direction pattern (most commonly seen with IN), these atoms are used to separately
        /// track whether the names have been used as properties and/or pseudo-properties.
        /// </remarks>
        static class PseudoPropertyAtoms
        {
            public static readonly ZilAtom Desc = new("?DESC?", null, StdAtom.None);
            public static readonly ZilAtom Location = new("?IN/LOC?", null, StdAtom.None);
        }

        /// <summary>
        /// Looks through a <see cref="ZilModelObject"/>'s property definitions, creating the
        /// property builders, flag builders, and vocab word builders that it will need.
        /// </summary>
        /// <remarks>
        /// <para>This does not create the <see cref="IObjectBuilder"/> or add any data to it.</para>
        /// <para>It does, however, call the <c>PROPSPEC</c> routines for any properties that have
        /// custom handlers installed, and replaces the corresponding property definitions with
        /// whatever the handler returned.</para>
        /// </remarks>
        /// <param name="model">The object to examine.</param>
        void PreBuildObject(ZilModelObject model)
        {
            // TODO: split up PreBuildObject method

            var globalsByName = Context.ZEnvironment.Globals.ToDictionary(g => g.Name);
            var propertiesSoFar = new HashSet<ZilAtom>();

            var preBuilders = new ComplexPropDef.ElementPreBuilders
            {
                CreateVocabWord = (atom, partOfSpeech, src) =>
                {
                    // ReSharper disable once SwitchStatementMissingSomeCases
                    switch (partOfSpeech.StdAtom)
                    {
                        case StdAtom.ADJ:
                        case StdAtom.ADJECTIVE:
                            Context.ZEnvironment.GetVocabAdjective(atom, src);
                            break;

                        case StdAtom.NOUN:
                        case StdAtom.OBJECT:
                            Context.ZEnvironment.GetVocabNoun(atom, src);
                            break;

                        case StdAtom.BUZZ:
                            Context.ZEnvironment.GetVocabBuzzword(atom, src);
                            break;

                        case StdAtom.PREP:
                            Context.ZEnvironment.GetVocabPreposition(atom, src);
                            break;

                        case StdAtom.DIR:
                            Context.ZEnvironment.GetVocabDirection(atom, src);
                            break;

                        case StdAtom.VERB:
                            Context.ZEnvironment.GetVocabVerb(atom, src);
                            break;

                        default:
                            Context.HandleError(new CompilerError(model, CompilerMessages.Unrecognized_0_1, "part of speech", partOfSpeech));
                            break;
                    }
                },

                ReserveGlobal = atom =>
                {
                    if (globalsByName.TryGetValue(atom, out var g))
                        g.StorageType = GlobalStorageType.Hard;
                }
            };

            // for detecting implicitly defined directions
            var directionPattern = Context.GetProp(
                Context.GetStdAtom(StdAtom.DIRECTIONS), Context.GetStdAtom(StdAtom.PROPSPEC)) as ComplexPropDef;

            // create property builders for all properties on this object as needed,
            // and set up P?FOO constants for them. also create vocabulary words for 
            // SYNONYM and ADJECTIVE property values, and constants for FLAGS values.
            foreach (var prop in model.Properties)
            {
                using var foo = DiagnosticContext.Push(prop.SourceLine);

                // the first element must be an atom identifying the property
                if (prop.IsCons(out var first, out var propBody) && first is ZilAtom atom)
                {
                    PreBuildProperty(model, propertiesSoFar, preBuilders, directionPattern, prop, propBody, atom);
                }
                else
                {
                    Context.HandleError(new CompilerError(prop, CompilerMessages.Property_Specification_Must_Start_With_An_Atom));
                }
            }
        }

        private void PreBuildProperty(ZilModelObject model, HashSet<ZilAtom> propertiesSoFar, ComplexPropDef.ElementPreBuilders preBuilders, ComplexPropDef? directionPattern, ZilList prop, ZilListoidBase propBody, ZilAtom atom)
        {
            ZilAtom? uniquePropertyName;

            // exclude phony built-in properties
            bool phony;
            bool? isSynonym = null;
            Synonym? synonym = null;

            /* We also detect direction properties here, which are tricky for a few reasons:
             * - They can be implicitly defined by a property spec that looks sufficiently direction-like.
             * - (IN ROOMS) is not a direction, even if IN has been explicitly defined as a direction...
             *   but (IN "string") is!
             * - (FOO BAR) is not enough to implicitly define FOO as a direction, even if (DIR R:ROOM)
             *   is a pattern for directions.
             *
             * Thus, there are a few ways to write a property that ZILF will recognize as a direction.
             *
             * If the property name has already been defined as one (e.g. by <DIRECTIONS>), you can either:
             *   - Put two or more values after the property name: (NORTH TO FOREST), (NORTH 123 456)
             *   - Put one value after the property name that isn't an atom: (NORTH "You can't go that way.")
             *
             * If it hasn't been defined as a direction, you can still implicitly define it right here:
             *   - Put two or more values after the property name, *and* match the PROPDEF for DIRECTIONS:
             *     (STARBOARD TO BRIG), (PORT SORRY "You can't jump that far.")
             */

            var isKnownDirectionName = Context.ZEnvironment.Directions.Contains(atom);

            var isDirectionProp = isKnownDirectionName
                ? propBody.HasLengthAtLeast(2) || !(propBody.IsEmpty || propBody.First is ZilAtom)
                : propBody.HasLengthAtLeast(2) && directionPattern?.Matches(Context, prop) == true;

            if (isDirectionProp)
            {
                // it's a direction
                phony = false;

                // could be a new implicitly defined direction
                if (!isKnownDirectionName)
                {
                    synonym = Context.ZEnvironment.Synonyms.FirstOrDefault(s => s.SynonymWord.Atom == atom);

                    if (synonym == null)
                    {
                        isSynonym = false;
                        Context.ZEnvironment.Directions.Add(atom);
                        Context.ZEnvironment.GetVocabDirection(atom, prop.SourceLine ?? SourceLines.Unknown);
                        if (directionPattern != null)
                            Context.SetPropDef(atom, directionPattern);
                        uniquePropertyName = atom;
                    }
                    else
                    {
                        isSynonym = true;
                        uniquePropertyName = synonym.OriginalWord.Atom;
                    }
                }
                else
                {
                    uniquePropertyName = atom;
                }
            }
            else
            {
                // ReSharper disable once SwitchStatementMissingSomeCases
                switch (atom.StdAtom)
                {
                    case StdAtom.DESC:
                        phony = true;
                        uniquePropertyName = PseudoPropertyAtoms.Desc;
                        break;
                    case StdAtom.IN:
                        // (IN FOO) is a location, but (IN "foo") is a property
                        if (propBody.First is ZilAtom)
                            goto case StdAtom.LOC;
                        goto default;
                    case StdAtom.LOC:
                        phony = true;
                        uniquePropertyName = PseudoPropertyAtoms.Location;
                        break;
                    case StdAtom.FLAGS:
                        phony = true;
                        // multiple FLAGS definitions are OK
                        uniquePropertyName = null;
                        break;
                    default:
                        phony = false;
                        uniquePropertyName = atom;
                        break;
                }
            }

            if (uniquePropertyName != null)
            {
                if (!propertiesSoFar.Add(uniquePropertyName))
                {
                    Context.HandleError(new CompilerError(
                        prop,
                        CompilerMessages.Duplicate_0_Definition_1,
                        phony ? "pseudo-property" : "property",
                        atom.ToStringContext(Context, false)));
                }
            }

            if (!phony)
            {
                PropertyDefinitions.TryAdd(atom, prop.SourceLine);

#pragma warning disable CA1864 // Prefer the 'IDictionary.TryAdd(TKey, TValue)' method
                if (!Properties.ContainsKey(atom))
                {
                    if (isSynonym == null)
                    {
                        synonym = Context.ZEnvironment.Synonyms.FirstOrDefault(s => s.SynonymWord.Atom == atom);
                        isSynonym = (synonym != null);
                    }

                    if (isSynonym.Value)
                    {
                        Debug.Assert(synonym != null);

                        var origAtom = synonym.OriginalWord.Atom;
                        PropertyDefinitions.TryAdd(origAtom, prop.SourceLine);
                        if (!Properties.TryGetValue(origAtom, out var origPb))
                        {
                            DefineProperty(origAtom);
                            origPb = Properties[origAtom];
                        }
                        Properties.Add(atom, origPb);

                        var pAtom = ZilAtom.Parse("P?" + atom.Text, Context);
                        Constants.Add(pAtom, origPb);

                        var origSpec = Context.GetProp(origAtom, Context.GetStdAtom(StdAtom.PROPSPEC));
                        Context.PutProp(atom, Context.GetStdAtom(StdAtom.PROPSPEC), origSpec);
                    }
                    else
                    {
                        DefineProperty(atom);
                    }
                }
#pragma warning restore CA1864 // Prefer the 'IDictionary.TryAdd(TKey, TValue)' method
            }

            // check for a PROPSPEC
            var propspec = Context.GetProp(atom, Context.GetStdAtom(StdAtom.PROPSPEC));
            if (propspec != null)
            {
                if (propspec is ComplexPropDef complexDef)
                {
                    // PROPDEF pattern
                    if (complexDef.Matches(Context, prop))
                    {
                        complexDef.PreBuildProperty(Context, prop, preBuilders);
                    }
                }
                else
                {
                    // name of a custom property builder function
                    var form = new ZilForm(new[] { propspec, prop }) { SourceLine = prop.SourceLine };
                    var specOutput = (ZilObject)form.Eval(Context);

                    if (specOutput is ZilListoidBase list && list.StdTypeAtom == StdAtom.LIST &&
                        list.Rest is { IsEmpty: false } customBody)
                    {
                        // replace the property body with the propspec's output
                        prop.Rest = customBody;
                    }
                    else
                    {
                        Context.HandleError(new CompilerError(model,
                            CompilerMessages.PROPSPEC_For_Property_0_Returned_A_Bad_Value_1, atom, specOutput));
                    }
                }
            }
            else
            {
                // ReSharper disable once SwitchStatementMissingSomeCases
                switch (atom.StdAtom)
                {
                    case StdAtom.SYNONYM:
                        foreach (var word in propBody.OfType<ZilAtom>())
                        {
                            try
                            {
                                Context.ZEnvironment.GetVocabNoun(word, prop.SourceLine ?? SourceLines.Unknown);
                            }
                            catch (ZilError ex)
                            {
                                Context.HandleError(ex);
                            }
                        }
                        break;

                    case StdAtom.ADJECTIVE:
                        foreach (var word in propBody.OfType<ZilAtom>())
                        {
                            try
                            {
                                Context.ZEnvironment.GetVocabAdjective(word, prop.SourceLine ?? SourceLines.Unknown);
                            }
                            catch (ZilError ex)
                            {
                                Context.HandleError(ex);
                            }
                        }
                        break;

                    case StdAtom.PSEUDO:
                        foreach (var word in propBody.OfType<ZilString>())
                        {
                            try
                            {
                                Context.ZEnvironment.GetVocabNoun(ZilAtom.Parse(word.Text, Context), prop.SourceLine ?? SourceLines.Unknown);
                            }
                            catch (ZilError ex)
                            {
                                Context.HandleError(ex);
                            }
                        }
                        break;

                    case StdAtom.FLAGS:
                        foreach (var word in propBody.OfType<ZilAtom>())
                        {
                            try
                            {
                                DefineFlag(Context.ZEnvironment.TryGetBitSynonym(word, out var original)
                                    ? original
                                    : word);
                                FlagDefinitions.TryAdd(word, prop.SourceLine);
                            }
                            catch (ZilError ex)
                            {
                                Context.HandleError(ex);
                            }
                        }
                        break;
                }
            }
        }

        /// <summary>
        /// Fills in an <see cref="IObjectBuilder"/>'s metadata and property values from the object definition.
        /// </summary>
        /// <param name="model">The object definition.</param>
        /// <param name="ob">The object builder.</param>
        /// <remarks>
        /// <para>By the time this method runs, <see cref="PreBuildObject"/> has already done some validation,
        /// defined whatever builders and constants we need for the object, and possibly replaced some property
        /// definitions by calling <c>PROPSPEC</c> functions. What's left is compiling the constant values in
        /// those definitions and putting them in the object/property tables.</para>
        /// </remarks>
        void BuildObject(ZilModelObject model, IObjectBuilder ob)
        {
            var elementConverters = new ComplexPropDef.ElementConverters
            {
                CompileConstant = CompileConstant,

                GetAdjectiveValue = (atom, src) =>
                {
                    var word = Context.ZEnvironment.GetVocabAdjective(atom, src);
                    return Context.ZEnvironment.ZVersion == 3
                        ? Constants[ZilAtom.Parse("A?" + word.Atom.Text, Context)]
                        : Vocabulary[word];
                },

                GetGlobalNumber = atom =>
                {
                    if (Globals.TryGetValue(atom, out var num))
                        return num;

                    Context.HandleError(new CompilerError(atom, CompilerMessages.Undefined_0_1, "global", atom));
                    return Game.Zero;
                },

                GetVocabWord = (atom, partOfSpeech, src) =>
                {
                    IWord word;

                    // ReSharper disable once SwitchStatementMissingSomeCases
                    switch (partOfSpeech.StdAtom)
                    {
                        case StdAtom.ADJ:
                        case StdAtom.ADJECTIVE:
                            word = Context.ZEnvironment.GetVocabAdjective(atom, src);
                            break;

                        case StdAtom.NOUN:
                        case StdAtom.OBJECT:
                            word = Context.ZEnvironment.GetVocabNoun(atom, src);
                            break;

                        case StdAtom.BUZZ:
                            word = Context.ZEnvironment.GetVocabBuzzword(atom, src);
                            break;

                        case StdAtom.PREP:
                            word = Context.ZEnvironment.GetVocabPreposition(atom, src);
                            break;

                        case StdAtom.DIR:
                            word = Context.ZEnvironment.GetVocabDirection(atom, src);
                            break;

                        case StdAtom.VERB:
                            word = Context.ZEnvironment.GetVocabVerb(atom, src);
                            break;

                        default:
                            Context.HandleError(new CompilerError(model, CompilerMessages.Unrecognized_0_1, "part of speech", partOfSpeech));
                            return Game.Zero;
                    }

                    return Vocabulary[word];
                }
            };

            foreach (var prop in model.Properties)
            {
                ITableBuilder tb;
                int length = 0;
                var src = prop.SourceLine ?? SourceLines.Unknown;

                bool noSpecialCases = false;

                // the first element must be an atom identifying the property
                if (!prop.IsCons(out var first, out var propBody) || first is not ZilAtom propName)
                {
                    Context.HandleError(new CompilerError(model, CompilerMessages.Property_Specification_Must_Start_With_An_Atom));
                    continue;
                }

                // check for IN/LOC, which can take precedence over PROPSPEC
                var value = propBody.First;
                var valueAtom = value as ZilAtom;
                if (propName.StdAtom == StdAtom.LOC ||
                    (propName.StdAtom == StdAtom.IN && propBody.GetLength(1) == 1 && valueAtom != null))
                {
                    if (valueAtom == null)
                    {
                        Context.HandleError(new CompilerError(model, CompilerMessages.Values_For_0_Property_Must_Be_1, propName, "atoms"));
                        continue;
                    }
                    if (!Objects.TryGetValue(valueAtom, out var parent))
                    {
                        Context.HandleError(new CompilerError(
                            model,
                            CompilerMessages.No_Such_Object_0,
                            valueAtom.ToString()));
                        continue;
                    }
                    ob.Parent = parent;
                    ob.Sibling = parent.Child;
                    parent.Child = ob;
                    continue;
                }

                // check for a PUTPROP giving a PROPDEF pattern or hand-coded property builder
                var propspec = Context.GetProp(propName, Context.GetStdAtom(StdAtom.PROPSPEC));
                if (propspec != null)
                {
                    if (propspec is ComplexPropDef complexDef)
                    {
                        // PROPDEF pattern
                        if (complexDef.Matches(Context, prop))
                        {
                            tb = ob.AddComplexProperty(Properties[propName]);
                            complexDef.BuildProperty(Context, prop, tb, elementConverters);
                            continue;
                        }
                    }
                    else
                    {
                        // name of a custom property builder function
                        // PreBuildObject already called the function and replaced the property body
                        noSpecialCases = true;
                    }
                }

                // built-in property builder, so at least one value has to follow the atom (except for FLAGS)
                if (value == null)
                {
                    if (propName.StdAtom != StdAtom.FLAGS)
                        Context.HandleError(new CompilerError(model, CompilerMessages.Property_Has_No_Value_0, propName.ToString()));
                    continue;
                }

                // check for special cases
                bool handled = false;
                if (!noSpecialCases)
                {
                    // ReSharper disable once SwitchStatementMissingSomeCases
                    switch (propName.StdAtom)
                    {
                        case StdAtom.DESC:
                            if (value.StdTypeAtom != StdAtom.STRING)
                            {
                                Context.HandleError(new CompilerError(model, CompilerMessages.Values_For_0_Property_Must_Be_1, propName, "strings"));
                                continue;
                            }
                            ob.DescriptiveName = TranslateString((ZilString)value, Context);
                            // skip the length validation
                            continue;

                        case StdAtom.FLAGS:
                            foreach (var obj in propBody)
                            {
                                if (obj is not ZilAtom atom)
                                {
                                    Context.HandleError(new CompilerError(model, CompilerMessages.Values_For_0_Property_Must_Be_1, propName, "atoms"));
                                    break;
                                }

                                if (Context.ZEnvironment.TryGetBitSynonym(atom, out var original))
                                    atom = original;

                                var fb = Flags[atom];
                                ob.AddFlag(fb);
                            }
                            // skip the length validation
                            continue;

                        case StdAtom.SYNONYM:
                            handled = true;
                            tb = ob.AddComplexProperty(Properties[propName]);
                            foreach (var obj in propBody)
                            {
                                if (obj is not ZilAtom atom)
                                {
                                    Context.HandleError(new CompilerError(model, CompilerMessages.Values_For_0_Property_Must_Be_1, propName, "atoms"));
                                    break;
                                }

                                var word = Context.ZEnvironment.GetVocabNoun(atom, src);
                                var wb = Vocabulary[word];
                                tb.AddWord(wb);
                                length += 2;
                            }
                            break;

                        case StdAtom.ADJECTIVE:
                            handled = true;
                            tb = ob.AddComplexProperty(Properties[propName]);
                            foreach (var obj in propBody)
                            {
                                if (obj is not ZilAtom atom)
                                {
                                    Context.HandleError(new CompilerError(model, CompilerMessages.Values_For_0_Property_Must_Be_1, propName, "atoms"));
                                    break;
                                }

                                var word = Context.ZEnvironment.GetVocabAdjective(atom, src);
                                var wb = Vocabulary[word];
                                if (Context.ZEnvironment.ZVersion == 3)
                                {
                                    tb.AddByte(Constants[ZilAtom.Parse("A?" + word.Atom.Text, Context)]);
                                    length++;
                                }
                                else
                                {
                                    tb.AddWord(wb);
                                    length += 2;
                                }
                            }
                            break;

                        case StdAtom.PSEUDO:
                            handled = true;
                            tb = ob.AddComplexProperty(Properties[propName]);
                            foreach (var obj in propBody)
                            {
                                if (obj is ZilString str)
                                {
                                    var word = Context.ZEnvironment.GetVocabNoun(ZilAtom.Parse(str.Text, Context), src);
                                    var wb = Vocabulary[word];
                                    tb.AddWord(wb);
                                }
                                else
                                {
                                    tb.AddWord(CompileConstant(obj)!);
                                }
                                length += 2;
                            }
                            break;

                        case StdAtom.GLOBAL:
                            if (Context.ZEnvironment.ZVersion == 3)
                            {
                                handled = true;
                                tb = ob.AddComplexProperty(Properties[propName]);
                                foreach (var obj in propBody)
                                {
                                    if (obj is not ZilAtom atom)
                                    {
                                        Context.HandleError(new CompilerError(model, CompilerMessages.Values_For_0_Property_Must_Be_1, propName, "atoms"));
                                        break;
                                    }

                                    if (!Objects.TryGetValue(atom, out var ob2))
                                    {
                                        Context.HandleError(new CompilerError(model, CompilerMessages.No_Such_Object_0, atom));
                                        break;
                                    }

                                    tb.AddByte(ob2);
                                    length++;
                                }
                            }
                            break;
                    }
                }

                if (!handled)
                {
                    // nothing special, just one or more words
                    var pb = Properties[propName];
                    if (propBody.Rest?.IsEmpty != false)
                    {
                        var word = CompileConstant(value);
                        if (word == null)
                        {
                            Context.HandleError(new CompilerError(
                                prop,
                                CompilerMessages.Nonconstant_Initializer_For_0_1_2,
                                "property",
                                propName,
                                value));
                            word = Game.Zero;
                        }
                        ob.AddWordProperty(pb, word);
                        length = 2;
                    }
                    else
                    {
                        tb = ob.AddComplexProperty(pb);
                        foreach (var obj in propBody)
                        {
                            var word = CompileConstant(obj);
                            if (word == null)
                            {
                                Context.HandleError(new CompilerError(
                                    prop,
                                    CompilerMessages.Nonconstant_Initializer_For_0_1_2,
                                    "property",
                                    propName,
                                    obj));
                                word = Game.Zero;
                            }
                            tb.AddWord(word);
                            length += 2;
                        }
                    }
                }

                // check property length
                if (length > Game.MaxPropertyLength)
                {
                    Context.HandleError(new CompilerError(
                        prop,
                        CompilerMessages.Property_0_Is_Too_Long_Max_1_Byte1s,
                        propName.ToStringContext(Context, true),
                        Game.MaxPropertyLength));
                }
            }

            //XXX debug line refs for objects
            if (WantDebugInfo)
                Game.DebugFile!.MarkObject(ob, new DebugLineRef(), new DebugLineRef());
        }
    }
}
