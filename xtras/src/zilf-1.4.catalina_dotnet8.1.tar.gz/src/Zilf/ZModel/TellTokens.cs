﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Zilf.Diagnostics;
using Zilf.Interpreter;
using Zilf.Interpreter.Values;
using Zilf.Language;

namespace Zilf.ZModel
{
    sealed class TellPattern
    {
        public sealed class MatchResult
        {
            public bool Matched { get; set; }
            public ZilForm? Output { get; set; }

            public IList<ZilObject> Captures { get; }

            public MatchResult()
            {
                Captures = new List<ZilObject>();
            }
        }

        abstract class Token
        {
            public abstract bool Match(Context ctx, ZilObject input, MatchResult result);
        }

        sealed class AtomToken : Token
        {
            public List<ZilAtom> Atoms { get; }

            public AtomToken()
            {
                Atoms = new List<ZilAtom>();
            }

            public override bool Match(Context ctx, ZilObject input, MatchResult result)
            {
                return Atoms.Any(atom => input == atom);
            }
        }

        sealed class AnyToken : Token
        {
            public override bool Match(Context ctx, ZilObject input, MatchResult result)
            {
                result.Captures.Add(input);
                return true;
            }
        }

        sealed class DeclToken : Token
        {
            // ReSharper disable once MemberCanBePrivate.Local
            [DisallowNull]
            public ZilObject? Pattern { get; set; }

            public override bool Match(Context ctx, ZilObject input, MatchResult result)
            {
                if (!Decl.Check(ctx, input, Pattern!))
                    return false;

                result.Captures.Add(input);
                return true;
            }
        }

        sealed class GvalToken : Token
        {
            // ReSharper disable once MemberCanBePrivate.Local
            public ZilAtom? Atom { get; set; }

            public override bool Match(Context ctx, ZilObject input, MatchResult result) =>
                input is ZilForm form
                && form.IsGVAL(out var inputAtom)
                && inputAtom == Atom;
        }

        readonly Token[] tokens;
        readonly ZilForm outputForm;

        TellPattern(Token[] tokens, ZilForm outputForm)
        {
            this.tokens = tokens;
            this.outputForm = outputForm;
        }

        internal ZilForm OutputTemplate => outputForm;

        /// <exception cref="InterpreterError">The pattern syntax is invalid.</exception>
        public static IEnumerable<TellPattern> Parse(IEnumerable<ZilObject> spec)
        {
            var tokensSoFar = new List<Token>();
            int capturesSoFar = 0;

            foreach (var zo in spec)
            {
                AtomToken atomToken;

                switch (zo)
                {
                    case ZilList when tokensSoFar.Count > 0:
                        throw new InterpreterError(InterpreterMessages.Lists_And_Atoms_In_TELL_Token_Specs_Must_Come_At_The_Beginning);

                    case ZilList list:
                        // one or more atoms to introduce the token
                        atomToken = new AtomToken();

                        if (list.IsEmpty || !list.All(e => e is ZilAtom))
                        {
                            throw new InterpreterError(
                                list.SourceLine,
                                InterpreterMessages._0_In_1_Must_Be_2,
                                "lists",
                                "TELL token specs",
                                "lists of atoms");
                        }

                        foreach (var o in list.Cast<ZilAtom>())
                            atomToken.Atoms.Add(o);

                        tokensSoFar.Add(atomToken);
                        break;

                    case ZilAtom { StdAtom: StdAtom.Times }:
                        // * to capture any value...
                        tokensSoFar.Add(new AnyToken());
                        capturesSoFar++;
                        break;

                    case ZilAtom when tokensSoFar.Count > 0:
                        throw new InterpreterError(InterpreterMessages.Lists_And_Atoms_In_TELL_Token_Specs_Must_Come_At_The_Beginning);

                    case ZilAtom atom:
                        // ...or any other atom to introduce the token
                        atomToken = new AtomToken();
                        atomToken.Atoms.Add(atom);
                        tokensSoFar.Add(atomToken);
                        break;

                    case ZilAdecl { First: ZilAtom { StdAtom: StdAtom.Times}, Second: var decl }:
                        // *:DECL to capture any value that matches the decl
                        tokensSoFar.Add(new DeclToken { Pattern = decl });
                        capturesSoFar++;
                        break;

                    case ZilAdecl:
                        throw new InterpreterError(
                            InterpreterMessages._0_Must_Be_1,
                            "left side of ADECL in TELL token spec",
                            "'*'");

                    case ZilForm form when form.IsGVAL(out var gvAtom):
                        // <GVAL atom> to match an exact GVAL...
                        tokensSoFar.Add(new GvalToken { Atom = gvAtom });
                        break;

                    case ZilForm form:
                        // ...or any other FORM to specify the pattern's output
                        // validate the output FORM
                        int lvalCount = 0;
                        foreach (var elem in form)
                        {
                            if (elem.IsLVAL(out _))
                            {
                                lvalCount++;
                            }
                            else if (!IsSimpleOutputElement(elem))
                            {
                                throw new InterpreterError(
                                    form,
                                    InterpreterMessages.Unrecognized_Value_In_TELL_Output_Template_0,
                                    elem);
                            }
                        }

                        if (lvalCount != capturesSoFar)
                            throw new InterpreterError(
                                form,
                                InterpreterMessages.Expected_0_LVAL0s_In_TELL_Output_Template_But_Found_1,
                                capturesSoFar,
                                lvalCount);

                        var pattern = new TellPattern(tokensSoFar.ToArray(), form);
                        tokensSoFar.Clear();
                        capturesSoFar = 0;
                        yield return pattern;
                        break;

                    default:
                        throw new InterpreterError(
                            zo.SourceLine,
                            InterpreterMessages.Unrecognized_Value_In_TELL_Token_Spec_0,
                            zo);
                }
            }

            if (tokensSoFar.Count != 0)
            {
                throw new InterpreterError(InterpreterMessages.TELL_Token_Spec_Ends_With_An_Unterminated_Pattern);
            }
        }

        public int Length => tokens.Length;

        public MatchResult Match(IList<ZilObject> input, int startIndex, Context ctx, ISourceLine src)
        {
            var result = new MatchResult { Matched = false };

            if (input.Count - startIndex < tokens.Length)
            {
                return result;
            }

            for (int i = 0; i < tokens.Length; i++)
            {
                if (!tokens[i].Match(ctx, input[startIndex + i], result))
                {
                    return result;
                }
            }

            result.Matched = true;
            var outputElements = new List<ZilObject>();
            int nextCapture = 0;
            foreach (var element in outputForm)
            {
                if (element is ZilForm form)
                {
                    if (form.First is ZilAtom atom && atom.StdAtom == StdAtom.LVAL)
                    {
                        outputElements.Add(result.Captures[nextCapture++]);
                        continue;
                    }
                }

                outputElements.Add(element);
            }
            result.Output = new ZilForm(outputElements) { SourceLine = src };

            return result;
        }

        static bool IsSimpleOutputElement(ZilObject obj)
        {
            return obj is ZilAtom or ZilFix or ZilString or ZilFalse or ZilForm { IsEmpty: true } || obj.IsLVAL(out _) || obj.IsGVAL(out _);
        }
    }
}
